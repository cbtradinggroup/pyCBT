This package includes tools for downloading instrument series & analysis of risk for improved
investment in the FOREX
