# possible solutions: oandapyV20.endpoints.pricing.PricingStream
#
# define stream class
#   load account data
#   parse parameters (timezone, instruments)
