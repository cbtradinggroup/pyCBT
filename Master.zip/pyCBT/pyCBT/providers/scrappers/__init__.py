# TODO: build common package with modules:
#       * tables (for parsing tables, units, etc)
#       * cmdline (for parsing command line)
#       * decorators (for locale setting, etc)
#       * output (for processing tables to output streams)
